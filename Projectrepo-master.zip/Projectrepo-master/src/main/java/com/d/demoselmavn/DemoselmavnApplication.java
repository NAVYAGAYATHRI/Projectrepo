package com.d.demoselmavn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoselmavnApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoselmavnApplication.class, args);
	}

}
